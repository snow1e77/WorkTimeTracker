declare module '@env' {
  export const APP_NAME: string;
  export const VERSION: string;
  export const ENVIRONMENT: string;
} 