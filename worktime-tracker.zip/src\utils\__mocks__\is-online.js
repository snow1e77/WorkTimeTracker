const isOnline = jest.fn(() => Promise.resolve(true));

module.exports = isOnline; 