Write-Host "=== WorkTimeTracker Deployment ===" -ForegroundColor Green
Write-Host "Server: root@185.132.127.139" -ForegroundColor Cyan
Write-Host "Domain: gabygg.nu" -ForegroundColor Cyan

$confirm = Read-Host "Continue deployment? (y/N)"
if ($confirm -ne 'y') {
    Write-Host "Cancelled" -ForegroundColor Red
    exit
}

Write-Host "Creating archive..." -ForegroundColor Yellow

# Create temp directory
$tempDir = "$env:TEMP\worktime-deploy"
if (Test-Path $tempDir) {
    Remove-Item $tempDir -Recurse -Force
}

# Copy files excluding unnecessary directories
robocopy . $tempDir /E /XD .git node_modules server\node_modules server\logs server\uploads .expo /XF *.zip /NFL /NDL /NJH /NJS

# Create ZIP archive
Compress-Archive -Path "$tempDir\*" -DestinationPath "worktime-tracker.zip" -Force
Remove-Item $tempDir -Recurse -Force

Write-Host "Archive created: worktime-tracker.zip" -ForegroundColor Green

Write-Host "Copying to server..." -ForegroundColor Yellow
Write-Host "Password: aJttmb8rQuJIbvDP" -ForegroundColor Cyan

scp worktime-tracker.zip root@185.132.127.139:/opt/

Write-Host "Connecting to server..." -ForegroundColor Yellow
Write-Host "Execute commands from server-commands.sh file on server" -ForegroundColor Cyan

ssh root@185.132.127.139

Write-Host "Deployment completed!" -ForegroundColor Green
Write-Host "Check: https://gabygg.nu" -ForegroundColor Cyan 