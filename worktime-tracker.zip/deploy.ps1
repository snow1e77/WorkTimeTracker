# Скрипт развертывания WorkTimeTracker в продакшене
# IP: 185.132.127.139
# Домен: gabygg.nu

param(
    [switch]$Force
)

# Настройки
$DOMAIN = "gabygg.nu"
$SERVER_IP = "185.132.127.139"
$SERVER_USER = "root"

Write-Host "=== Развертывание WorkTimeTracker ===" -ForegroundColor Green
Write-Host "Сервер: $SERVER_USER@$SERVER_IP" -ForegroundColor Cyan
Write-Host "Домен: $DOMAIN" -ForegroundColor Cyan

if (-not $Force) {
    $confirm = Read-Host "Продолжить развертывание? (y/N)"
    if ($confirm -ne 'y' -and $confirm -ne 'Y') {
        Write-Host "Развертывание отменено" -ForegroundColor Red
        exit 1
    }
}

try {
    Write-Host "Создание архива проекта..." -ForegroundColor Yellow
    
    # Создаем ZIP архив исключая ненужные папки
    $tempDir = "$env:TEMP\worktime-deploy"
    if (Test-Path $tempDir) {
        Remove-Item $tempDir -Recurse -Force
    }
    
    # Копируем файлы исключая ненужные
    robocopy . $tempDir /E /XD .git node_modules server\node_modules server\logs server\uploads .expo /XF *.zip /NFL /NDL /NJH /NJS
    
    # Создаем ZIP
    Compress-Archive -Path "$tempDir\*" -DestinationPath "worktime-tracker.zip" -Force
    Remove-Item $tempDir -Recurse -Force
    
    Write-Host "Архив создан успешно" -ForegroundColor Green
    
    Write-Host "Копирование на сервер..." -ForegroundColor Yellow
    
    # Копируем архив на сервер  
    scp worktime-tracker.zip root@185.132.127.139:/opt/
    
    Write-Host "Выполнение команд развертывания на сервере..." -ForegroundColor Yellow
    
    # Выполняем развертывание на сервере
    $deployCommands = @'
# Обновление системы
dnf update -y

# Установка пакетов
dnf install -y git docker docker-compose nginx certbot python3-certbot-nginx firewalld fail2ban unzip

# Запуск сервисов
systemctl start docker
systemctl enable docker
systemctl start firewalld
systemctl enable firewalld

# Настройка firewall
firewall-cmd --permanent --add-service=http
firewall-cmd --permanent --add-service=https
firewall-cmd --permanent --add-port=3001/tcp
firewall-cmd --reload

# Развертывание
cd /opt
rm -rf WorkTimeTracker
mkdir WorkTimeTracker
unzip -q worktime-tracker.zip -d WorkTimeTracker
rm worktime-tracker.zip
cd WorkTimeTracker
chown -R root:root .

# Создание .env для сервера
cat > server/.env << 'EOF'
NODE_ENV=production
PORT=3001
JWT_SECRET=your-super-secret-jwt-key-that-must-be-at-least-32-characters-long
DB_HOST=db
DB_PORT=5432
DB_NAME=worktime_tracker_prod
DB_USER=worktime_user
DB_PASSWORD=YourSecureDBPassword123!
DB_SSL=false
CORS_ORIGINS=https://gabygg.nu,https://www.gabygg.nu
ENABLE_MONITORING=true
LOG_LEVEL=info
EOF

# Создание .env для Docker
cat > .env << 'EOF'
DB_PASSWORD=YourSecureDBPassword123!
POSTGRES_PASSWORD=YourSecureDBPassword123!
DOMAIN=gabygg.nu
JWT_SECRET=your-super-secret-jwt-key-that-must-be-at-least-32-characters-long
REDIS_PASSWORD=RedisSecurePassword123!
EOF

echo "Переменные окружения созданы"

# SSL сертификаты
echo "Настройка SSL..."
certbot certonly --standalone --agree-tos --email admin@gabygg.nu --no-eff-email -d gabygg.nu -d www.gabygg.nu || echo "SSL уже настроен"

# Автообновление SSL
echo "0 12 * * * /usr/bin/certbot renew --quiet" | crontab -

# Запуск приложения
echo "Запуск приложения..."
docker-compose -f docker-compose.production.yml down || true
docker image prune -f
docker-compose -f docker-compose.production.yml up -d

echo "=== Развертывание завершено ==="
'@
    
    $deployCommands | ssh root@$SERVER_IP
    
    # Удаляем локальный архив
    Remove-Item "worktime-tracker.zip" -ErrorAction SilentlyContinue
    
    Write-Host "Проверка работоспособности..." -ForegroundColor Yellow
    Start-Sleep 15
    
    try {
        $response = Invoke-WebRequest -Uri "https://$DOMAIN/health" -TimeoutSec 30 -ErrorAction SilentlyContinue
        if ($response.StatusCode -eq 200) {
            Write-Host "Приложение работает корректно!" -ForegroundColor Green
            Write-Host "Доступно по адресу: https://$DOMAIN" -ForegroundColor Cyan
        }
        else {
            Write-Host "Приложение может быть недоступно" -ForegroundColor Yellow
        }
    }
    catch {
        Write-Host "Не удается подключиться к приложению пока" -ForegroundColor Yellow
    }
    
    Write-Host "" 
    Write-Host "=== Развертывание завершено успешно! ===" -ForegroundColor Green
    Write-Host "Приложение: https://$DOMAIN" -ForegroundColor Cyan
    Write-Host "Админ панель: https://$DOMAIN/admin" -ForegroundColor Cyan
    Write-Host "Health check: https://$DOMAIN/health" -ForegroundColor Cyan
    
}
catch {
    Write-Host "Ошибка развертывания: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
} 