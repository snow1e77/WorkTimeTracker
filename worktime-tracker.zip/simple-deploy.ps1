# Простой скрипт развертывания WorkTimeTracker
Write-Host "=== Развертывание WorkTimeTracker ===" -ForegroundColor Green
Write-Host "Сервер: root@185.132.127.139" -ForegroundColor Cyan
Write-Host "Домен: gabygg.nu" -ForegroundColor Cyan

$confirm = Read-Host "Продолжить? (y/N)"
if ($confirm -ne 'y') {
    exit
}

try {
    Write-Host "Создание архива..." -ForegroundColor Yellow
    
    # Создаем временную папку
    $tempDir = "$env:TEMP\worktime-deploy"
    if (Test-Path $tempDir) {
        Remove-Item $tempDir -Recurse -Force
    }
    
    # Копируем нужные файлы
    Write-Host "Копирование файлов..." -ForegroundColor Yellow
    robocopy . $tempDir /E /XD .git node_modules server\node_modules server\logs server\uploads .expo /XF *.zip /NFL /NDL /NJH /NJS
    
    # Создаем ZIP
    Compress-Archive -Path "$tempDir\*" -DestinationPath "worktime-tracker.zip" -Force
    Remove-Item $tempDir -Recurse -Force
    
    Write-Host "Архив создан: worktime-tracker.zip" -ForegroundColor Green
    
    Write-Host "Копирование на сервер..." -ForegroundColor Yellow
    scp worktime-tracker.zip root@185.132.127.139:/opt/
    
    Write-Host "Подключение к серверу для развертывания..." -ForegroundColor Yellow
    Write-Host "Пароль: aJttmb8rQuJIbvDP" -ForegroundColor Cyan
    
    # Подключаемся по SSH для выполнения команд
    ssh root@185.132.127.139
    
    # Удаляем локальный архив
    Remove-Item "worktime-tracker.zip" -ErrorAction SilentlyContinue
    
    Write-Host "Готово! Проверьте https://gabygg.nu" -ForegroundColor Green
    
}
catch {
    Write-Host "Ошибка: $($_.Exception.Message)" -ForegroundColor Red
} 