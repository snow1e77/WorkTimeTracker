#!/bin/bash

# Команды для выполнения на сервере AlmaLinux
# После подключения по SSH выполните эти команды:

echo "=== Настройка сервера AlmaLinux ==="

# Обновление системы
dnf update -y

# Установка пакетов
dnf install -y git docker docker-compose nginx certbot python3-certbot-nginx firewalld fail2ban unzip curl

# Запуск сервисов
systemctl start docker
systemctl enable docker
systemctl start firewalld
systemctl enable firewalld
systemctl start fail2ban
systemctl enable fail2ban

# Настройка firewall
firewall-cmd --permanent --add-service=http
firewall-cmd --permanent --add-service=https
firewall-cmd --permanent --add-port=3001/tcp
firewall-cmd --reload

echo "=== Развертывание приложения ==="

# Переход в папку проекта
cd /opt

# Удаление старой версии
rm -rf WorkTimeTracker

# Создание новой папки
mkdir WorkTimeTracker

# Распаковка архива
unzip -q worktime-tracker.zip -d WorkTimeTracker

# Удаление архива
rm worktime-tracker.zip

# Переход в папку проекта
cd WorkTimeTracker

# Установка прав
chown -R root:root .

echo "=== Создание конфигурационных файлов ==="

# Создание .env для сервера
cat > server/.env << 'EOF'
NODE_ENV=production
PORT=3001
JWT_SECRET=your-super-secret-jwt-key-that-must-be-at-least-32-characters-long-for-production
DB_HOST=db
DB_PORT=5432
DB_NAME=worktime_tracker_prod
DB_USER=worktime_user
DB_PASSWORD=YourSecureDBPassword123!
DB_SSL=false
CORS_ORIGINS=https://gabygg.nu,https://www.gabygg.nu
ENABLE_MONITORING=true
LOG_LEVEL=info
EOF

# Создание .env для Docker Compose
cat > .env << 'EOF'
DB_PASSWORD=YourSecureDBPassword123!
POSTGRES_PASSWORD=YourSecureDBPassword123!
DOMAIN=gabygg.nu
JWT_SECRET=your-super-secret-jwt-key-that-must-be-at-least-32-characters-long-for-production
REDIS_PASSWORD=RedisSecurePassword123!
EOF

echo "Переменные окружения созданы"

echo "=== Настройка SSL сертификатов ==="

# Остановка nginx если запущен
systemctl stop nginx || true

# Получение SSL сертификата
certbot certonly --standalone \
    --agree-tos \
    --email admin@gabygg.nu \
    --no-eff-email \
    -d gabygg.nu \
    -d www.gabygg.nu || echo "SSL уже настроен или ошибка получения"

# Автообновление SSL
echo "0 12 * * * /usr/bin/certbot renew --quiet" | crontab -

echo "=== Запуск приложения ==="

# Остановка старых контейнеров
docker-compose -f docker-compose.production.yml down || true

# Очистка старых образов
docker image prune -f

# Сборка и запуск
docker-compose -f docker-compose.production.yml up -d

echo "=== Проверка статуса ==="

# Ожидание запуска
sleep 30

# Проверка контейнеров
docker-compose -f docker-compose.production.yml ps

# Проверка логов
echo "Последние логи API:"
docker-compose -f docker-compose.production.yml logs --tail=20 api

echo ""
echo "=== Развертывание завершено! ==="
echo "Приложение: https://gabygg.nu"
echo "Health check: https://gabygg.nu/health" 
echo "Админ панель: https://gabygg.nu/admin"
echo ""
echo "Для проверки логов используйте:"
echo "docker-compose -f docker-compose.production.yml logs -f" 