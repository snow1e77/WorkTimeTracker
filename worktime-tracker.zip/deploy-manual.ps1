Write-Host "=== Развертывание WorkTimeTracker ===" -ForegroundColor Green
Write-Host "Сервер: root@185.132.127.139" -ForegroundColor Cyan

$confirm = Read-Host "Продолжить? (y/N)"
if ($confirm -ne 'y') {
    Write-Host "Отменено" -ForegroundColor Red
    exit
}

Write-Host "Создание архива..." -ForegroundColor Yellow

# Создаем временную папку
$tempDir = "$env:TEMP\worktime-deploy"
if (Test-Path $tempDir) {
    Remove-Item $tempDir -Recurse -Force
}

# Копируем файлы
robocopy . $tempDir /E /XD .git node_modules server\node_modules server\logs server\uploads .expo /XF *.zip /NFL /NDL /NJH /NJS

# Создаем ZIP
Compress-Archive -Path "$tempDir\*" -DestinationPath "worktime-tracker.zip" -Force
Remove-Item $tempDir -Recurse -Force

Write-Host "Архив создан" -ForegroundColor Green

Write-Host "Копирование на сервер..." -ForegroundColor Yellow
Write-Host "Пароль: aJttmb8rQuJIbvDP" -ForegroundColor Cyan

scp worktime-tracker.zip root@185.132.127.139:/opt/

Write-Host "Подключение к серверу..." -ForegroundColor Yellow
Write-Host "Выполните команды из файла server-commands.sh" -ForegroundColor Cyan

ssh root@185.132.127.139

Write-Host "Развертывание завершено!" -ForegroundColor Green
Write-Host "Проверьте: https://gabygg.nu" -ForegroundColor Cyan 